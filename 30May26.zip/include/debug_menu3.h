#ifndef GUARD_DEBUG_MENU3_H
#define GUARD_DEBUG_MENU3_H

#include "structs/menu.h"
#include "structs/str_text.h"

// size: 0xFC
typedef struct unkStruct_203B3F4
{
    /* 0x0 */ u32 state;
    /* 0x4 */ u8 friendArea;
    /* 0x8 */ u32 menuAction;
    /* 0xC */ MenuItem menuItems[8];
    MenuStruct unk4C;
    WindowTemplates unk9C;
} unkStruct_203B3F4;

#endif // GUARD_DEBUG_MENU3_H
